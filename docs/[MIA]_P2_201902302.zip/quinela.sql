insert into MEMBRESIA values (1,'Gold',900);
insert into MEMBRESIA values (2,'Silver',450);
insert into MEMBRESIA values (3,'Bronze',150);    

select * from TIPOUSUARIO;
select * from MEMBRESIA;